include("shared.lua")

local color_red = Color(140, 0, 0, 100)
local color_white = Color(255, 255, 255)

local renderDist = 250 * 250
function ENT:Draw()
	self:DrawModel()
	if not self.size then
		self.size = self:OBBMaxs().z + 10
	end
	local me = LocalPlayer()
	if me:GetPos():DistToSqr(self:GetPos()) > renderDist then return end
	local ang = self:GetAngles();
	ang:RotateAroundAxis(ang:Forward(), 90);
	ang:RotateAroundAxis(ang:Right(), -90);
	
	cam.Start3D2D(self:GetPos() + Vector(0,0,self.size), Angle(0, me:EyeAngles().y - 90, 90), 0.1) 
    draw.SimpleTextOutlined(language.GetPhrase(self:GetWeaponName()).PrintName, "DermaLarge", 0 , 0, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0)) 
    draw.SimpleTextOutlined("Исчезнет через "..math.Round(self:GetCreationTime() + 60*5 - CurTime()), "DermaDefault", 0 , 20, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0)) 
    cam.End3D2D()

end

--[[
function ENT:Draw()
    local ret = hook.Call("onDrawSpawnedWeapon", nil, self)
    if ret ~= nil then return end
    self:DrawModel()

    local amount = self:Getamount()
    if amount == 1 then return end

    local Pos = self:GetPos()
    local Ang = self:GetAngles()
    local text = DarkRP.getPhrase("amount") .. amount

    surface.SetFont("HUDNumber5")
    local TextWidth = surface.GetTextSize(text)

    Ang:RotateAroundAxis(Ang:Forward(), 90)

    cam.Start3D2D(Pos + Ang:Up(), Ang, 0.11)
        draw.WordBox(2, 0, -40, text, "HUDNumber5", color_red, color_white)
    cam.End3D2D()

    Ang:RotateAroundAxis(Ang:Right(), 180)

    cam.Start3D2D(Pos + Ang:Up() * 3, Ang, 0.11)
        draw.WordBox(2, -TextWidth, -40, text, "HUDNumber5", color_red, color_white)
    cam.End3D2D()
end
--]]

--[[---------------------------------------------------------------------------
Create a shipment from a spawned_weapon
---------------------------------------------------------------------------]]
properties.Add("createShipment",
    {
        MenuLabel   =   DarkRP.getPhrase("createshipment"),
        Order       =   2003,
        MenuIcon    =   "icon16/add.png",

        Filter      =   function(self, ent, ply)
                            if not IsValid(ent) then return false end
                            return ent.IsSpawnedWeapon
                        end,

        Action      =   function(self, ent)
                            if not IsValid(ent) then return end
                            RunConsoleCommand("darkrp", "makeshipment", ent:EntIndex())
                        end
    }
)

--[[---------------------------------------------------------------------------
Interface
---------------------------------------------------------------------------]]
DarkRP.hookStub{
    name = "onDrawSpawnedWeapon",
    description = "Draw spawned weapons.",
    realm = "Client",
    parameters = {
        {
            name = "weapon",
            description = "The weapon to perform drawing operations on.",
            type = "Player"
        }
    },
    returns = {
        {
            name = "value",
            description = "Return a value to completely override drawing",
            type = "any"
        }
    }
}
